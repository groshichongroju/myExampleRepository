//
//  ViewController.swift
//  LoadTable
//
//  Created by CTS_DEP_AMM00217 on 22/11/16.
//  Copyright © 2016 CTS_DEP_AMM00217. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
//        let label = UILabel(frame: CGRectMake(50, 100, 200, 21))
//        //label.center = CGPointMake(160, 284)
//        label.textAlignment = NSTextAlignment.Center
//         label.text = "I'am a test label"
//        label.textColor=UIColor.blackColor();
//        label.backgroundColor=UIColor.grayColor();
//         self.view.addSubview(label);
        
           }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func groshiGIDlogin(sender: AnyObject) {
        
        
    }
    

}

